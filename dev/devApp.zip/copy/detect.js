if(screen.width > 600)
         {
			// alert("Screen width is greater than 600px");
          // document.write("<link rel='stylesheet' href='window.css'>");
         }
      else
         {
			//  alert("Screen width is less than 600px");
           // document.write("<link rel='stylesheet' href='style.css'>");
         }
